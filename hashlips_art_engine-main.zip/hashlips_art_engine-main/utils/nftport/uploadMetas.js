const fetch = require("node-fetch");
const path = require("path");
const basePath = process.cwd();
const fs = require("fs");

fs.writeFileSync(`${basePath}/build/json/_ipfsMetas.json`, "");
const writter = fs.createWriteStream(`${basePath}/build/json/_ipfsMetas.json`, {
  flags: "a",
});
writter.write("[");
const readDir = `${basePath}/build/json`;
let fileCount = fs.readdirSync(readDir).length - 2;

fs.readdirSync(readDir).forEach((file) => {
  if (file == "_metadata.json" || file === "_ipfsMetas.json") return;

  const jsonFile = fs.readFileSync(`${readDir}/${file}`);

  let url = "https://api.nftport.xyz/v0/metadata";

  let options = {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: "4b8d723f-1a2f-4d23-9d7a-bfdd5facd4ed",
    },
    body: jsonFile,
  };

  fetch(url, options)
    .then((res) => res.json())
    .then((json) => {
      writter.write(JSON.stringify(json, null, 2));
      fileCount--;
      if (fileCount === 0) {
        writter.write("]");
        writter.end();
      } else {
        writter.write(",\n");
      }
      console.log(`${json.name} metadata uploaded & added to _ipfsMetas.json`);
    })
    .catch((err) => console.error("error:" + err));
});
