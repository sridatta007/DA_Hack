const fetch = require("node-fetch");
const path = require("path");
const basePath = process.cwd();
const fs = require("fs");

const ipfsMetas = JSON.parse(
  fs.readFileSync(`${basePath}/build/json/_ipfsMetas.json`)
);

fs.writeFileSync(`${basePath}/build/minted.json`, "");
const writter = fs.createWriteStream(`${basePath}/build/minted.json`, {
  flags: "a",
});
writter.write("[");
let fileCount = ipfsMetas.length;

ipfsMetas.forEach((meta) => {
  let url = "https://api.nftport.xyz/v0/mints/customizable";

  const mintInfo = {
    chain: "rinkeby",
    contract_address: "0x89B802524dd242b7326d394BA4EAd788d0a85636",
    metadata_uri:
      "ipfs://bafkreib5a6ge53v2otx7h22qbgfv5a45uydlaq23p53ry66xodhu3q56u4",
    mint_to_address: "0x437D39a716C1F8c98138Bb37279f5E429854e8f1",
    token_id: meta.custom_fields,
  };

  let options = {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: "4b8d723f-1a2f-4d23-9d7a-bfdd5facd4ed",
    },
    body: JSON.stringify(mintInfo),
  };

  fetch(url, options)
    .then((res) => res.json())
    .then((json) => {
      console.log(json);
      writter.write(JSON.stringify(json, null, 2));
      fileCount--;
      if (fileCount === 0) {
        writter.write("]");
        writter.end();
      } else {
        writter.write(",\n");
      }
      console.log(`Minted: ${json.transaction_external_url}`);
    })
    .catch((err) => console.error("error:" + err));
});
